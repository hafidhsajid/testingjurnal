<footer>
    <div class="container">
      <div class="row">
        <div class="col-12 text-center">
          <p class="pt-4 pb-2">
            2020 Copyright SV Store. KMM-Exca-Rizquna-Zahra
          </p>
        </div>
      </div>
    </div>
  </footer><?php /**PATH C:\laragon\www\ecomsvkmm\resources\views/includes/footer.blade.php ENDPATH**/ ?>